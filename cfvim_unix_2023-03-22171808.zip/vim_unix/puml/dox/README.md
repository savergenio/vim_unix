# structure-of-doxygen-doc
The Structure of Doxygen Documentation

See http://alesnosek.com/blog/2015/06/21/the-structure-of-doxygen-documentation/
