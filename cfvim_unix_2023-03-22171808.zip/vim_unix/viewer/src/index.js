import Vue from 'vue'
import Preview from './preview.vue'
import './index.scss'

new Vue({
  el: '#app',
  render: h => h(Preview)
})
