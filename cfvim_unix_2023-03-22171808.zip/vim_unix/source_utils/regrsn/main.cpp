#include <iostream>
#include <string>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <array>
#include <sys/stat.h>
#include <unistd.h>
#include <string>
#include <fstream>
#include <iostream>
#include <iostream>
#include <stdio.h>
#include <dirent.h>

using namespace std;

std::string current_working_dir()
{
    char tmp[256];
    getcwd(tmp, 256);
    return tmp;
}

bool srch_string(const string &full_path, const string &srch_dir)
{
    bool ret_val = false;
    std::size_t find_test = full_path.find(srch_dir.c_str());
    if (find_test != std::string::npos)
    {
        ret_val = true;
    }
    return ret_val;
}

std::string extract_ruby_file(const string &full_path)
{
    std::string srch_str2 = ".rb ";
    std::string str2;

    std::size_t find_test = full_path.find(srch_str2.c_str());

    if (find_test != std::string::npos)
    {
        str2 = full_path.substr(0, find_test + 4);
    }
    return str2;
}

std::string extract_ruby_arg(const string &full_path)
{
    std::string srch_str2 = " -dut ";
    std::string srch_str3 = " -trexdefaults ";
    std::string str2;

    std::size_t find_test = full_path.find(srch_str2.c_str());

    if (find_test != std::string::npos)
    {
        str2 = full_path.substr(find_test);
    }

    std::size_t find_text_def = str2.find(srch_str3.c_str());

    //cout << " < " << find_test << "," << find_text_def << endl;
    if (find_text_def != std::string::npos)
    {
        str2 = str2.substr(0, find_text_def);
    }

    return str2;
}

std::string root_dir(const string &pcode_dir, const string &srch_dir)
{
    std::string str2;

    std::size_t find_test = pcode_dir.find(srch_dir.c_str());

    if (find_test != std::string::npos)
    {
        str2 = pcode_dir.substr(0, find_test - 1);
    }
    return str2;
}

inline bool bFileExist(const std::string &name)
{
    return ( access( name.c_str(), F_OK ) != -1 );
}

inline void fn_removeLastCharAsNewLine(std::string &strLine)
{
    if (!strLine.empty() && strLine[strLine.length() - 1] == '\n')
    {
        strLine.erase(strLine.length() - 1);
    }
}

enum DIE_TYPE
{
    GNRD_IO    = 0,
    GNRD_XEON  = 1,
    GNR_ATOM   = 2,
    GNR_IO     = 3,
    GNR_IO_A0  = 4,
    GNR_XEON   = 5,
    GRR        = 6
};

int main(int argc, char *argv[])
{
    string xml_file;
    string cpp_file;
    string root_proj_path;
    std::string command("find");
    std::string rgrsna("regression");
    bool is_regression_dir = false;
    std::array<char, 2048> buffer;
    std::string result;
    std::string level0_file_fail = "level0.fail";

    DIE_TYPE dType;


    cout << "cwd      =" << current_working_dir() <<  "\n";
    //cout << "root dir =" << root_dir(current_working_dir()) <<  "\n";
    //string root_proj_path;
    is_regression_dir = srch_string(current_working_dir(), rgrsna);
    if (!is_regression_dir)
    {
        cout << "not regression dir\n";
        return 0;
    }

    FILE *pipe = popen(command.c_str(), "r");
    if (!pipe)
    {
        std::cerr << "Couldn't start command." << std::endl;
        return 0;
    }
    while (fgets(buffer.data(), 128, pipe) != NULL)
    {
        if (is_regression_dir = srch_string(buffer.data(), level0_file_fail))
        {
            std::string level0_file_str = buffer.data();

            ifstream ifstream_level0FileHandle;
            string levelzeroFileContent_line;

            fn_removeLastCharAsNewLine(level0_file_str);

            ifstream_level0FileHandle.open(level0_file_str);

            if (ifstream_level0FileHandle.is_open())
            {
                if (srch_string(level0_file_str, "gnrd_io"))
                {
                    dType = GNRD_IO;
                }
                if (srch_string(level0_file_str, "gnrd_xeon"))
                {
                    dType = GNRD_XEON;
                }
                if (srch_string(level0_file_str, "gnr_atom"))
                {
                    dType = GNR_ATOM;
                }
                if (srch_string(level0_file_str, "gnr_io"))
                {
                    dType = GNR_IO;
                }
                if (srch_string(level0_file_str, "gnr_io_a0"))
                {
                    dType = GNR_IO_A0;
                }
                if (srch_string(level0_file_str, "gnr_xeon"))
                {
                    dType = GNR_XEON;
                }
                if (srch_string(level0_file_str, "grr"))
                {
                    dType = GRR;
                }

                //cout << level0_file_str << endl;

                while (getline(ifstream_level0FileHandle, levelzeroFileContent_line))
                {
                    if (levelzeroFileContent_line[0] != '#')
                    {
                        //cout << "Full String   :" << levelzeroFileContent_line << endl;
                        //cout << "Full RubyFile :" << extract_ruby_file(levelzeroFileContent_line) << endl;
                        //cout << "Arg RubyFile :"  << extract_ruby_arg(levelzeroFileContent_line) << endl;
                        cout << "trex " << extract_ruby_file(levelzeroFileContent_line) <<  " " <<  extract_ruby_arg(levelzeroFileContent_line) << ":w"<< endl;
                    }
                }
            }
            ifstream_level0FileHandle.close();

            //result += buffer.data();
        }
    }
    auto returnCode = pclose(pipe);
    //cout << result <<"\r\n";


    return 0;
}
