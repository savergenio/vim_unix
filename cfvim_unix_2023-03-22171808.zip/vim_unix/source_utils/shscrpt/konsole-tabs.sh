# Based on http://www.linuxjournal.com/content/start-and-control-konsole-dbus

# Start sessions in konsole.
function konsole_start_sessions()
{
    local nsessions=0
    local i session_num

    for ((i = 1; i <= $#; )); do
        local name="${!i}"
        let i++
        local profile="${!i}"
        let i++
        local cmd="${!i}"
        let i++

        session_num=$(qdbus org.kde.konsole /Konsole org.kde.konsole.Window.newSession "$profile" "$HOME")
        sleep 0.1
        qdbus org.kde.konsole "/Sessions/$session_num" setTitle 0 "$name" </dev/null &>/dev/null
        sleep 0.1
        qdbus org.kde.konsole "/Sessions/$session_num" setTitle 1 "$name" </dev/null &>/dev/null
        sleep 0.1
        qdbus org.kde.konsole "/Sessions/$session_num" sendText "$cmd"$'\n' </dev/null &>/dev/null
        sleep 0.1

        let nsessions++
    done

    # Activate first session.
    for ((; nsessions > 1; nsessions--)); do
        qdbus org.kde.konsole /Konsole prevSession </dev/null &>/dev/null
    done
}
