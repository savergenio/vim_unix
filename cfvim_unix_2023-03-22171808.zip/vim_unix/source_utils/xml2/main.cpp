#include "pugixml.hpp"

#include <vector>
#include <iostream>
//#include <filesystem>
#include <sys/stat.h>
#include <unistd.h>
#include <string>
#include <fstream>
#include <iostream>
#include <iostream>
#include <stdio.h>
#include <dirent.h>
/* C Includes */
# include <stdio.h>
# include <stdlib.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <dirent.h>
# include <getopt.h>
# include <unistd.h>
# include <signal.h>
# include <string.h>
# include "main.hpp"



int main(int argc, char *argv[])
{
    string xml_file;
    string cpp_file;
    string root_proj_path;

    string root_src_ip;
    string root_src_flow;
    string root_tsrc_ip;
    string root_tsrc_flow;
    string root_mock;
    string local_mock;


    string target_src_dir;
    string target_test_dir;

    bool   is_flow = is_flow_dir(get_cwd_as_string());

    root_proj_path = find_root_dir();

    //cout << "is_flow_dir=" << is_flow  << endl;
    //cout << "root_dir=" << root_proj_path << endl;

    browse_dir(get_cwd_as_string());
    xml_file =  find_test_xml(get_cwd_as_string());
    cpp_file =  find_test_cpp(get_cwd_as_string());

    //cout << "test xml=" << find_test_xml(get_cwd_as_string()) << endl;
    //cout << "test cpp=" << find_test_cpp(get_cwd_as_string()) << endl;

    for (int i = 0; i < argc; ++i)
    {
        string s_in_arg = argv[i];

        if ((s_in_arg.find("_tests.xml") != string::npos))
        {
            xml_file = s_in_arg;
        }
        if ((s_in_arg.find("_ut.cpp") != string::npos))
        {
            cpp_file = s_in_arg;
        }
    }


    root_src_ip    = root_proj_path + "/src/ip";
    root_src_flow  = root_proj_path + "/src/flow";
    root_tsrc_ip   = root_proj_path + "/tests/ip";
    root_tsrc_flow = root_proj_path + "/tests/flow";
    root_mock      = root_proj_path + "/tests/mocks";
    local_mock     = current_working_dir() + "/mocks";

    cout << "--START--------------------------------------------------------\n";
    cout << "  xml file = " << xml_file <<  "\n";
    cout << "  cpp file = " << cpp_file <<  "\n";
    cout << "  cwd      = " << current_working_dir() <<  "\n";
    cout << "  root dir = " << root_dir(current_working_dir()) <<  "\n";
    cout << "  root proj= " << root_proj_path <<  "\n";


    cout << "  root_src_ip    :" << root_src_ip    << "\n";
    cout << "  root_src_flow  :" << root_src_flow  << "\n";
    cout << "  root_tsrc_ip   :" << root_tsrc_ip   << "\n";
    cout << "  root_tsrc_flow :" << root_tsrc_flow << "\n";
    cout << "  root_mock      :" << root_mock      << "\n";
    cout << "  local_mock     :" << local_mock     << "\n";
    cout << "--END--------------------------------------------------------\n";
    //return 0;

    if (is_flow)
    {
        target_src_dir  = "/home/vs/idev/man/src/flow";
        target_test_dir = "/home/vs/idev/man/tests/flow";
    }
    else
    {
        target_src_dir  = "/home/vs/idev/man/src/ip";
        target_test_dir = "/home/vs/idev/man/tests/ip";
    }




    //string root_proj_path;

    //return 0;
    if (bFileExist(xml_file))
    {
        pugi::xml_document doc;
        pugi::xml_parse_result result = doc.load_file(xml_file.c_str());
        pugi::xml_node project = doc.child("tests");

       ofstream mTagGenFile;
       mTagGenFile.open(LTAG_FILE);

       mTagGenFile << "#Writing test tag.\n";
#if 1
        for (pugi::xml_node tool = project.first_child(); tool; tool = tool.next_sibling())
        {
            std::string src_target_cpp_file = tool.child("src_file").text().get();
            if (src_target_cpp_file != "")
            {
                //std::cout << "---------------------------------\r\n";
                std::cout << "src: " << tool.child("src_file").text().get() << std::endl;
                std::cout << "ut : " << tool.child("ut").text().get() << std::endl;
                std::cout << "mod: " << tool.child("model").text().get() << std::endl;

                pugi::xpath_node_set ns_dep = tool.select_nodes("dep");
                mTagGenFile << "fctags --languages=c++,c  " << get_src_dir(get_cwd_as_string()) << "/" << mtrim(tool.child("src_file").text().get()) << std::endl;

                for (pugi::xpath_node n : ns_dep)
                {
                    pugi::xml_node node = n.node();
                    std::cout << "type_dir:" <<  node.child("type_dir").text().get() << "\r\n";
                    std::cout << "type_name:" <<  node.child("type_name").text().get() << "\r\n";
                    std::cout << "version:" <<  node.child("version").text().get() << "\r\n";
                    if(mtrim(node.child("type_dir").text().get())=="ip")
                    {
                        std::string spath = mtrim(node.child("type_dir").text().get());
                        spath += "/" +  mtrim(node.child("type_name").text().get());
                        spath += "/" +  mtrim(node.child("version").text().get());
                        mTagGenFile << "fctags --languages=c++,c  -R -a " << get_src_dir(get_cwd_as_string()) << "/" << mtrim(spath) << std::endl;
                    }
                }

                pugi::xpath_node_set ns_mock = tool.select_nodes("mock");
                std::cout << "ns_mock=" << ns_mock.size() << "\r\n";

                for (pugi::xpath_node n : ns_mock)
                {
                    pugi::xml_node node = n.node();
                    std::cout << "mock:" <<  node.text().get() << "\r\n";
                    std::string localMockFile= "./mocks/" + mtrim(node.text().get());
                    std::string globalMockFile= root_dir(current_working_dir()) + "/tests/mock_library/" + mtrim(node.text().get());
                    // Mock file is being included 
                    if(bFileExist(localMockFile))
                    {
                        mTagGenFile << "fctags --languages=c++,c  -R -a " << localMockFile << std::endl;
                    }
                    else if(bFileExist(globalMockFile))
                    {
                        mTagGenFile << "fctags --languages=c++,c  -R -a " << globalMockFile << std::endl;
                    }
                }
                std::cout << std::endl;
            }
#else
        for (pugi::xml_node tool = project.first_child(); tool; tool = tool.next_sibling())
        {
            std::cout << "---------------------------------\r\n";
            std::cout << "src: " << tool.child("src_file").text().get() << std::endl;
            std::cout << "ut : " << tool.child("ut").text().get() << std::endl;
            std::cout << "mod: " << tool.child("model").text().get() << std::endl;

            pugi::xpath_node_set ns_dep = tool.select_nodes("dep");

for (pugi::xpath_node n : ns_dep)
            {
                pugi::xml_node node = n.node();
                std::cout << "type_dir:" <<  node.child("type_dir").text().get() << "\r\n";
                std::cout << "type_name:" <<  node.child("type_name").text().get() << "\r\n";
                std::cout << "version:" <<  node.child("version").text().get() << "\r\n";
            }

            pugi::xpath_node_set ns_mock = tool.select_nodes("mock");
            std::cout << "ns_mock=" << ns_mock.size() << "\r\n";
for (pugi::xpath_node n : ns_mock)
            {
                pugi::xml_node node = n.node();
                std::cout << "mock:" <<  node.text().get() << "\r\n";
            }
            std::cout << std::endl;
        }
#endif
        }
       mTagGenFile.close();
       chmod(LTAG_FILE,S_IRWXU);
       system(LTAG_FILE);
    }
}

