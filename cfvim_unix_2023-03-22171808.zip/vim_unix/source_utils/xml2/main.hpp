#ifndef ___HH_MAIN_HPP
#define ___HH_MAIN_HPP

#include "pugixml.hpp"

#include <vector>
#include <iostream>
//#include <filesystem>
#include <sys/stat.h>
#include <unistd.h>
#include <string>
#include <fstream>
#include <iostream>
#include <iostream>
#include <stdio.h>
#include <dirent.h>
/* C Includes */
# include <stdio.h>
# include <stdlib.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <dirent.h>
# include <getopt.h>
# include <unistd.h>
# include <signal.h>
# include <string.h>
#include <sys/stat.h>

#define  LTAG_FILE "./get_ltag"
using namespace std;
using std::cout; using std::cin;
using std::endl; using std::string;

std::string mtrim(std::string istr)
{
    std::string str=istr;

    size_t endpos = str.find_last_not_of(" \t");
    size_t startpos = str.find_first_not_of(" \t");
    if( std::string::npos != endpos )
    {
        str = str.substr( 0, endpos+1 );
        str = str.substr( startpos );
    }
    else 
    {
        //str.erase(std::remove(std::begin(str), std::end(str), ' '), std::end(str));
    }
    // trim leading spaces
    startpos = str.find_first_not_of(" \t");
    if( string::npos != startpos )
    {
        str = str.substr( startpos );
    }
    return str;
}

//using std::filesystem::directory_iterator;
std::string current_working_dir()
{
    char tmp[256];
    getcwd(tmp, 256);
    return tmp;
}

bool is_flow_dir(const string &pcode_dir)
{
    bool retval = false;
    string flow_str = "flow";

    std::size_t find_flow = pcode_dir.find(flow_str);

    if (find_flow != std::string::npos)
    {
        retval = true;
    }

    return retval;
}

std::string root_dir(const string &pcode_dir)
{
    std::string str2;
    string test_str = "tests";

    std::size_t find_test = pcode_dir.find(test_str);

    if (find_test != std::string::npos)
    {
        str2 = pcode_dir.substr(0, find_test - 1);
    }
    return str2;
}

inline bool bFileExist(const std::string &name)
{
    return ( access( name.c_str(), F_OK ) != -1 );
}

char *get_cwd_as_charp(void)
{
    char buf[PATH_MAX];
    char *result = getcwd(buf, sizeof(buf));

    if (result == NULL)
    {
    }
    /* this can be a memleak if not freed again */
    /* but then ... how long does cdargs usually run? */
    return strdup(buf);
}

string get_cwd_as_string(void)
{
    char *cwd = get_cwd_as_charp();
    if (cwd == NULL)
    {
        return "";
    }
    else
    {
        string result = string(cwd);
        free(cwd);
        return result;
    }
}

string get_src_dir(const string pcode_dir)
{
    bool retval = false;
    string src_str  = "src";
    string test_str = "tests";
    string _pcode_dir=pcode_dir;


    std::size_t find_src  = _pcode_dir.find(src_str);
    std::size_t find_test = _pcode_dir.find(test_str);

    if (find_src != std::string::npos)
    {
        _pcode_dir.replace(_pcode_dir.find(src_str), src_str.length(), test_str);
    }
    if (find_test != std::string::npos)
    {
        _pcode_dir.replace(_pcode_dir.find(test_str), test_str.length(), src_str);
    }

    return _pcode_dir;

}

string find_root_dir(void)
{
    string pcode_dir = get_cwd_as_string();
    string src_str  = "src";
    string test_str = "tests";
    string str = "";

    std::size_t find_src  = pcode_dir.find(src_str);
    std::size_t find_test = pcode_dir.find(test_str);

    if (find_src != std::string::npos)
    {
        str = pcode_dir.substr(0, find_src - 1);
    }
    if (find_test != std::string::npos)
    {
        str = pcode_dir.substr(0, find_test - 1);
    }
    return str;
}

string browse_dir(const string &path)
{
    string xml_file = "";
    DIR *dir; struct dirent *diread;
    vector<char *> files;

    if ((dir = opendir(path.c_str())) != nullptr)
    {
        while ((diread = readdir(dir)) != nullptr)
        {
            files.push_back(diread->d_name);
        }
        closedir (dir);
    }

    for (auto file : files)
    {
        //..cout << file << " | ";
        //cout << " " <<  file << " " << endl;
        string s_in_arg = file;

        if ((s_in_arg.find("_tests.xml") != string::npos))
        {
            xml_file = s_in_arg;
        }
    }
    return xml_file;
}

string find_test_xml(const string &path, int index = 0)
{
    string xml_file = "";
    DIR *dir; struct dirent *diread;
    vector<char *> files;
    int  _index = 0;

    if ((dir = opendir(path.c_str())) != nullptr)
    {
        while ((diread = readdir(dir)) != nullptr)
        {
            files.push_back(diread->d_name);
        }
        closedir (dir);
    }

    for (auto file : files)
    {
        string s_in_arg = file;

        if ((s_in_arg.find("_tests.xml") != string::npos))
        {
            if (index == _index) xml_file = s_in_arg;
            _index++;
        }
    }
    return xml_file;
}

string find_test_cpp(const string &path, int index = 0)
{
    string cpp_file = "";
    DIR *dir; struct dirent *diread;
    vector<char *> files;
    int  _index = 0;

    if ((dir = opendir(path.c_str())) != nullptr)
    {
        while ((diread = readdir(dir)) != nullptr)
        {
            files.push_back(diread->d_name);
        }
        closedir (dir);
    }

    for (auto file : files)
    {
        string s_in_arg = file;

        if ((s_in_arg.find("_ut.cpp") != string::npos))
        {
            if (index == _index) cpp_file = s_in_arg;
            _index++;
        }
    }
    return cpp_file;
}


#endif /* ___HH_MAIN_HPP */
