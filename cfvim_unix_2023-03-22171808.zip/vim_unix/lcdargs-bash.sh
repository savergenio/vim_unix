# (C) 2002-2003 Dan Allen and Stefan Kamphausen

# Written by Dan Allen <dan@mojavelinux.com>
# - small additions by Stefan Kamphausen
# - better completion code by Robi Malik robi.malik@nexgo.de
# - trailing path support by Damon Harper <ds+dev-lcdargs@usrbin.ca> Feb 2006

# Globals
CDARGS_SORT=0   # set to 1 if you want mark to sort the list
CDARGS_NODUPS=1 # set to 1 if you want mark to delete dups

# --------------------------------------------- #
# Run the lcdargs program to get the target      #
# directory to be used in the various context   #
# This is the fundamental core of the           #
# bookmarking idea.  An alias or substring is   #
# expected and upon receiving one it either     #
# resolves the alias if it exists or opens a    #
# curses window with the narrowed down options  #
# waiting for the user to select one.           #
#                                               #
# @param  string alias                          #
#                                               #
# @access private                               #
# @return 0 on success, >0 on failure           #
# --------------------------------------------- #
function _lcdargs_get_dir ()
{
    local bookmark extrapath
    # if there is one exact match (possibly with extra path info after it),
    # then just use that match without calling lcdargs
    if [ -e "$HOME/.lcdargs" ]; then
        dir=`/bin/grep "^$1 " "$HOME/.lcdargs"`
        if [ -z "$dir" ]; then
            bookmark="${1/\/*/}"
            if [ "$bookmark" != "$1" ]; then
                dir=`/bin/grep "^$bookmark " "$HOME/.lcdargs"`
                extrapath=`echo "$1" | /bin/sed 's#^[^/]*/#/#'`
            fi
        fi
        [ -n "$dir" ] && dir=`echo "$dir" | /bin/sed 's/^[^ ]* //'`
    fi
    if [ -z "$dir" -o "$dir" != "${dir/
/}" ]; then
        # okay, we need lcdargs to resolve this one.
        # note: intentionally retain any extra path to add back to selection.
        dir=
        if lcdargs --noresolve "${1/\/*/}"; then
            dir=`cat "$HOME/.lcdargsresult"`
            /bin/rm -f "$HOME/.lcdargsresult";
        fi
    fi
    if [ -z "$dir" ]; then
        echo "Aborted: no directory selected" >&2
        return 1
    fi
    [ -n "$extrapath" ] && dir="$dir$extrapath"
    if [ ! -d "$dir" ]; then
        echo "Failed: no such directory '$dir'" >&2
        return 2
    fi
}

function _lpdargs_get_dir ()
{
    local bookmark extrapath

    if [ "$1" == "" ]; then
        dir=`lcdargs --flip`
    fi
    return 0;
}

# --------------------------------------------- #
# Perform the command (cp or mv) using the      #
# lcdargs bookmark alias as the target directory #
#                                               #
# @param  string command argument list          #
#                                               #
# @access private                               #
# @return void                                  #
# --------------------------------------------- #
function _cdargs_exec ()
{
    local arg dir i last call_with_browse

    # Get the last option which will be the bookmark alias
    eval last=\${$#};

    # Resolve the bookmark alias.  If it cannot resolve, the
    # curses window will come up at which point a directory
    # will need to be choosen.  After selecting a directory,
    # the function will continue and $_cdargs_dir will be set.
    if [ -e $last ]; then
        last=
    fi
    if _lcdargs_get_dir "$last"; then
        # For each argument save the last, move the file given in
        # the argument to the resolved lcdargs directory
        i=1;
        for arg; do
            if [ $i -lt $# ]; then
                $command "$arg" "$dir";
            fi
            let i=$i+1;
        done
    fi
}

# --------------------------------------------- #
# Prepare to move file list into the lcdargs     #
# target directory                              #
#                                               #
# @param  string command argument list          #
#                                               #
# @access public                                #
# @return void                                  #
# --------------------------------------------- #
function mvb ()
{
    local command

    command='mv -i';
    _cdargs_exec $*;
}

# --------------------------------------------- #
# Prepare to copy file list into the lcdargs     #
# target directory                              #
#                                               #
# @param  string command argument list          #
#                                               #
# @access public                                #
# @return void                                  #
# --------------------------------------------- #
function cpb ()
{
    local command

    command='cp -i';
    _cdargs_exec $*;
}

# --------------------------------------------- #
# Change directory to the lcdargs target         #
# directory                                     #
#                                               #
# @param  string alias                          #
#                                               #
# @access public                                #
# @return void                                  #
# --------------------------------------------- #
function cdb () 
{ 
    local dir

    _lcdargs_get_dir "$1" && cd "$dir" && echo `pwd` && PP $1;
}

function cdpcode() 
{
    local dir

    _lpdargs_get_dir "$1" && cd "$dir" && echo `pwd` && PP $1;
}
alias cb='cdb'
alias cv='cdb'
alias CD='cdb'
alias lcd='cdb'
alias lpd='cdpcode'
alias lct='cdpcode'

# --------------------------------------------- #
# Mark the current directory with alias         #
# provided and store as a lcdargs bookmark       #
# directory                                     #
#                                               #
# @param  string alias                          #
#                                               #
# @access public                                #
# @return void                                  #
# --------------------------------------------- #
function mark () 
{ 
    local tmpfile

    # first clear any bookmarks with this same alias, if file exists
    if [ "$CDARGS_NODUPS" -a -e "$HOME/.lcdargs" ]; then
        tmpfile=`echo ${TEMP:-${TMPDIR:-/tmp}} | /bin/sed -e "s/\\/$//"`
        tmpfile=$tmpfile/cdargs.$USER.$$.$RANDOM
        /bin/grep -v "^$1 " "$HOME/.lcdargs" > $tmpfile && 'mv' -f $tmpfile "$HOME/.lcdargs";
    fi
    # add the alias to the list of bookmarks
    lcdargs --add=":$1:`pwd`"; 
    # sort the resulting list
    if [ "$CDARGS_SORT" ]; then
        sort -o "$HOME/.lcdargs" "$HOME/.lcdargs";
    fi
}
# Oh, no! Not overwrite 'm' for stefan! This was 
# the very first alias I ever wrote in my un*x 
# carreer and will always be aliased to less...
# alias m='mark'

# --------------------------------------------- #
# Mark the current directory with alias         #
# provided and store as a lcdargs bookmark       #
# directory but do not overwrite previous       #
# bookmarks with same name                      #
#                                               #
# @param  string alias                          #
#                                               #
# @access public                                #
# @return void                                  #
# author: SKa                                   #
# --------------------------------------------- #
function ca ()
{
    # add the alias to the list of bookmarks
    lcdargs --add=":$1:`pwd`"; 
}
function lcdadd ()
{
    # add the alias to the list of bookmarks
    lcdargs --add=":$1:`pwd`"; 
}

# --------------------------------------------- #
# Bash programming completion for lcdargs        #
# Sets the $COMPREPLY list for complete         #
#                                               #
# @param  string substring of alias             #
#                                               #
# @access private                               #
# @return void                                  #
# --------------------------------------------- #
function _lcdargs_aliases ()
{
    local cur bookmark dir strip oldIFS
    COMPREPLY=()
    if [ -e "$HOME/.lcdargs" ]; then
        cur=${COMP_WORDS[COMP_CWORD]}
        if [ "$cur" != "${cur/\//}" ]; then # if at least one /
            bookmark="${cur/\/*/}"
            dir=`/bin/grep "^$bookmark " "$HOME/.lcdargs" | /bin/sed 's#^[^ ]* ##'`
            if [ -n "$dir" -a "$dir" = "${dir/
/}" -a -d "$dir" ]; then
                strip="${dir//?/.}"
                oldIFS="$IFS"
                IFS='
'
                COMPREPLY=( $(
                    compgen -d "$dir`echo "$cur" | /bin/sed 's#^[^/]*##'`" \
                        | /bin/sed -e "s/^$strip/$bookmark/" -e "s/\([^\/a-zA-Z0-9#%_+\\\\,.-]\)/\\\\\\1/g" ) )
                IFS="$oldIFS"
            fi
        else
            COMPREPLY=( $( (echo $cur ; cat "$HOME/.lcdargs") | \
                           awk 'BEGIN {first=1}
                                 {if (first) {cur=$0; l=length(cur); first=0}
                                 else if (substr($1,1,l) == cur) {print $1}}' ) )
        fi
    fi
    return 0
}

# --------------------------------------------- #
# Bash programming completion for lcdargs       #
# Set up completion (put in a function just so  #
# `nospace' can be a local variable)            #
#                                               #
# @param  none                                  #
#                                               #
# @access private                               #
# @return void                                  #
# --------------------------------------------- #
_cdargs_complete() {
  local nospace=
  [ "${BASH_VERSINFO[0]}" -ge 3 -o \( "${BASH_VERSINFO[0]}" = 2 -a \( "${BASH_VERSINFO[1]}" = 05a -o "${BASH_VERSINFO[1]}" = 05b \) \) ] && nospace='-o nospace'
  complete $nospace -S / -X '*/' -F _lcdargs_aliases cv cb cdb
  complete $nospace -S / -X '*/' -F _lcdargs_aliases CD cb cdb
  complete $nospace -S / -X '*/' -F _lcdargs_aliases lcd cb cdb
}

# Support ZSH via its BASH completion emulation
if [ -n "$ZSH_VERSION" ]; then
       autoload bashcompinit
       bashcompinit
elif [ -z "${BASH_VERSION}" ]; then
    # we do not support anything besides bash completion
    # (however patches to support other shells are very welcome)
    return 100
fi

_cdargs_complete
